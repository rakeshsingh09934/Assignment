package com.xebia.java.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.xebia.java.entity.XebiaCustomer;

@Repository
@Transactional
public interface XebiaRepository extends JpaRepository<XebiaCustomer, Integer>{

	@Modifying
	@Query(value = "delete from xebia_tb where id = :id", nativeQuery = true)
	public Integer deleteCustomerById(@Param("id") Integer id);

}
