package com.xebia.java.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xebia.java.entity.XebiaCustomer;
import com.xebia.java.service.XebiaServiceImpl;

@RestController
@RequestMapping(value = "/xebia")
public class XebiaAssignmentController {

	@Autowired
	private XebiaServiceImpl service;

	@PostMapping("/saveCustomer")
	public ResponseEntity<XebiaCustomer> saveCustomer(@RequestBody XebiaCustomer customer) {
		XebiaCustomer responseData = service.saveXebiaCustomer(customer);
		return new ResponseEntity<XebiaCustomer>(responseData, HttpStatus.OK);
	}
	
	@PutMapping("/updateCustomer/{id}")
	public ResponseEntity<XebiaCustomer> updateCustomer(@RequestBody XebiaCustomer customer, @PathVariable(name = "id") Integer id) {
		XebiaCustomer responseData = service.updateXebiaCustomer(customer, id);
		return new ResponseEntity<XebiaCustomer>(responseData, HttpStatus.OK);
	}
	
	@GetMapping("/getCustomer/{id}")
	public ResponseEntity<XebiaCustomer> findCustomerById(@PathVariable(name = "id") Integer id) {
		XebiaCustomer responseData = service.findCustomerById(id);
		if(null != responseData) {
			return new ResponseEntity<XebiaCustomer>(responseData, HttpStatus.OK);
		}
		return new ResponseEntity<XebiaCustomer>(HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping("/deleteCustomer/{id}")
	public ResponseEntity<String> deleteCustomerById(@PathVariable(name = "id") Integer id) {
		Boolean flag = service.deleteCustomerById(id);
		if(flag) {
			return new ResponseEntity<String>(HttpStatus.OK);
		}
		return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
	}
}
