package com.xebia.java.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "xebia_tb")
@Data
@NoArgsConstructor
public class XebiaCustomer {

	@Id
	@GeneratedValue
	private Integer id;
	private String slug;
	private String title;
	private String description;
	private String body;
	@CreatedDate
	private LocalDateTime createdAt;
	@LastModifiedDate
	private LocalDateTime updatedAt;
}
