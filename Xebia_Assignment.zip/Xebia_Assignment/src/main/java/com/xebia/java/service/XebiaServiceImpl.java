package com.xebia.java.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xebia.java.entity.XebiaCustomer;
import com.xebia.java.repository.XebiaRepository;

@Service
public class XebiaServiceImpl {

	@Autowired
	private XebiaRepository repo;
	
	public XebiaCustomer saveXebiaCustomer(XebiaCustomer customer) {
		String slug = String.join("-", customer.getTitle().split(" ")).toLowerCase();
		customer.setSlug(slug);
		customer.setCreatedAt(LocalDateTime.now());
		customer.setUpdatedAt(LocalDateTime.now());
		return repo.save(customer);
	}
	
	public XebiaCustomer updateXebiaCustomer(XebiaCustomer customer, Integer id) {
		XebiaCustomer cust = repo.findById(id).get();
		String slug = String.join("-", customer.getTitle().split(" ")).toLowerCase();
		cust.setSlug(slug);
		cust.setUpdatedAt(LocalDateTime.now());
		return repo.save(cust);
	}
	
	public XebiaCustomer findCustomerById(Integer id) {
		Optional<XebiaCustomer> cust = repo.findById(id);
		XebiaCustomer response = !cust.isEmpty() ? repo.findById(id).get() : null;
		return response;
	}
	
	public boolean deleteCustomerById(Integer id) {
		Optional<XebiaCustomer> cust = repo.findById(id);
		Integer response = !cust.isEmpty() ? repo.deleteCustomerById(id) : 0;
		Boolean flag = response != 0 ? true : false;
		return flag;
	}
}
